def test_API_setup:
    assert twitter_settup() is not None
