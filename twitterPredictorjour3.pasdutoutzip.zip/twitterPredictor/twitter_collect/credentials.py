# Twitter App access keys for @user

# Consume:
CONSUMER_KEY    = 'WS0jo6EQiIJ2XdykBFaj7VfqS'
CONSUMER_SECRET = 'wv7rJ1Nwq8p4P8YWXsuKWxo3eNnOpdxnNYkFpJvOdFgufyah5D'

# Access:
ACCESS_TOKEN  = '1062341820489887744-hhka9pbV9XMt2WJySBX9FEzGjTiIPj'
ACCESS_SECRET = 'sg0cXmpA5NRhszVLqfaWzPwxrtmgwAQ1E8SbttTJGyEIm'
