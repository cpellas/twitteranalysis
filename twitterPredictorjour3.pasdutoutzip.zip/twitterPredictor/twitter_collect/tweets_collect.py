# coding=utf-8
from twitterPredictor.twitter_collect.twitter_connection_setup import twitter_setup
import pandas as pd
import numpy as np
import matplotlib
matplotlib.use('TkAgg')
import matplotlib.pyplot as plt

# création d'un dataframe pour 10 tweets contenant le#EmmanuelMacron, avec les infos: auteur,dates,textes,hashtags et comme index l'index du tweet:
def collect():
    connexion = twitter_setup()
    tweets = connexion.search("#EmmanuelMacron", language="french", rpp=10)
    names=[]
    dates=[]
    texts=[]
    hashtag=[]
    index=[]
    for status in tweets:
        names.append(status.user.name)
        dates.append(status.created_at)
        texts.append(status.text)
        index.append(status.id_str)
        if len(status.entities.get('hashtags'))> 0:
            hashtag.append(status.entities.get('hashtags')[0].get("text"))
        else:
            hashtag.append("None")
    tweet=pd.DataFrame({"name":names,"date":dates,"text":texts,"hashtags":hashtag},index=index)
    print(tweet)

collect()

# collecter les 200 derniers tweets de l'utilisateur avec l'ID d'utilisateur= user_id
def collect_by_user(user_id):
    connexion = twitter_setup()
    statuses = connexion.user_timeline(id=user_id, count=1)
    for status in statuses:
        print(status.entities.get('hashtags')[0].get("text"))
    return statuses

import tweepy
from tweepy.streaming import StreamListener


class StdOutListener(StreamListener):
    # on vérifie que le listener n'a pas tenté d'acceder trop de fois en un
    # certain temps aux API en streaming, si c'est le cas: message d'erreur
    def on_data(self, data):
        print(data)
        return True

    def on_error(self, status):
        if str(status) == "420":
            print(status)
            print("You exceed a limited number of attempts to connect to the streaming API")
            return False
        else:
            return True


def collect_by_streaming():  # on collecte les tweets en direct grâce à un listener (objet de la classe que l'on vient de créer)

    connexion = twitter_setup()
    listener = StdOutListener()
    stream = tweepy.Stream(auth=connexion.auth, listener=listener)
    stream.filter(track=['Emmanuel Macron'])





